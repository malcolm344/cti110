#Malcolm Williams
#12122024
#p4lab1
#Write a turtle graphics programs that draws a triangle and a square using loops.


import turtle

# Set up the turtle window
window = turtle.Screen()

# Create the turtle object
t = turtle.Turtle()

# Draw the square using a for loop
for _ in range(4):
    t.forward(100)  # Move the turtle forward by 100 units
    t.left(90)  # Turn the turtle left by 90 degrees

# Move to a new position for the triangle without drawing
t.penup()  # Lift the pen
t.goto(50, 50)  # Move to the new position
t.pendown()  # Put the pen down to start drawing

# Draw the triangle using a for loop
for _ in range(3):
    t.forward(100)  # Move the turtle forward by 100 units
    t.left(120)  # Turn the turtle left by 120 degrees

# Close the window when clicked
window.exitonclick()







